import os
import json
import re

OUTPUT_DIR = "itemoutput/models"

def is_valid_texture_path(path):
    return re.match(r'^[a-z0-9_]+:(block|item)/[a-z0-9_/]+$', path) is not None

def check_model_file(filepath):
    errors = []
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        errors.append(f"❌ JSON構文エラー: {e}")
        return errors

    if "parent" not in data:
        errors.append("⚠️ 'parent' キーがありません")

    if "textures" in data:
        for key, value in data["textures"].items():
            if not isinstance(value, str):
                errors.append(f"❌ テクスチャ '{key}' の値が文字列ではありません: {value}")
            elif not is_valid_texture_path(value):
                errors.append(f"⚠️ テクスチャパスがForge 1.20.1形式でない: '{key}': '{value}'")
            elif "blocks/" in value or "items/" in value:
                errors.append(f"⚠️ 古いパス形式を検出: '{value}'")
    else:
        errors.append("⚠️ 'textures' キーがありません")

    return errors

def main():
    total = 0
    issues = 0
    for root, _, files in os.walk(OUTPUT_DIR):
        for file in files:
            if file.endswith(".json"):
                path = os.path.join(root, file)
                total += 1
                result = check_model_file(path)
                if result:
                    issues += 1
                    print(f"\n🚨 問題あり: {path}")
                    for err in result:
                        print("  ", err)

    print(f"\n🔍 チェック完了: {total} ファイル中 {issues} 件に問題が見つかりました")

if __name__ == "__main__":
    main()
