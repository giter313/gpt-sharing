import os
import re

input_folder = "output_src/render/boss"

def validate_boss_renderer(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()

    problems = []

    if "@SideOnly" in content:
        problems.append("⚠️ @SideOnly が残っています。Forge 1.20.1では不要です。")

    if "super.doRender" in content:
        problems.append("❌ super.doRender を使用しています。Forge 1.20.1では super.render に変更してください。")

    return problems

print("🔍 Boss Renderer 検証: " + input_folder)
all_files = sorted(os.listdir(input_folder))
has_errors = False

for filename in all_files:
    if not filename.endswith(".java"):
        continue

    full_path = os.path.join(input_folder, filename)
    problems = validate_boss_renderer(full_path)

    if problems:
        has_errors = True
        print(f"❗ {filename} に問題があります:")
        for problem in problems:
            print(f"   {problem}")
    else:
        print(f"✅ {filename} は正しく変換されています。")

if not has_errors:
    print("\n✔️ 全ファイルが正しく Forge 1.20.1 に適合しています。")
else:
    print("\n⚠️ 上記の問題を修正してください。")
