import os

INPUT_FOLDER = "input/buildings"
BROKEN_LINES_OUTPUT = "output/broken_lines.log"

def extract_broken_lines():
    os.makedirs(os.path.dirname(BROKEN_LINES_OUTPUT), exist_ok=True)
    with open(BROKEN_LINES_OUTPUT, "w", encoding="utf-8") as out_f:
        for filename in os.listdir(INPUT_FOLDER):
            if not filename.endswith(".txt"):
                continue
            filepath = os.path.join(INPUT_FOLDER, filename)
            with open(filepath, "r", encoding="utf-8") as f:
                for lineno, line in enumerate(f, start=1):
                    if line.startswith("Block"):
                        parts = line.strip().split(",")
                        if len(parts) != 7:
                            out_f.write(f"{filename}:{lineno}: {line}")

if __name__ == "__main__":
    extract_broken_lines()
    print(f"不正行を {BROKEN_LINES_OUTPUT} に保存しました。")
