import os
import re

target_dir = "output_src/render/npc"

# 条件：GeoEntityRenderer を使っているか？
def validate_code(code):
    errors = []

    # 1. GeoEntityRenderer インポートがあるか
    if "software.bernie.geckolib.renderer.GeoEntityRenderer" not in code:
        errors.append("Missing import: GeoEntityRenderer")

    # 2. GeoEntityRenderer を継承しているか
    if not re.search(r'extends\s+GeoEntityRenderer<[^>]+>', code):
        errors.append("Class does not extend GeoEntityRenderer<T>")

    # 3. 古いAPI使用の警告コメントが残っているか
    if "GL11." in code or "GL12." in code or "GlStateManager." in code:
        errors.append("Deprecated OpenGL usage detected")

    return errors

for filename in os.listdir(target_dir):
    if filename.endswith(".java"):
        path = os.path.join(target_dir, filename)
        with open(path, 'r', encoding='utf-8') as f:
            code = f.read()

        problems = validate_code(code)
        if problems:
            print(f"[⚠️ 検証失敗] {filename}")
            for p in problems:
                print(f"   - {p}")
        else:
            print(f"[✅ 検証OK] {filename}")
