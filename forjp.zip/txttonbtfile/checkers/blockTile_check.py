import os
import re

# --- 検証対象フォルダ ---
converted_folder = "output_src/block/tile"

# --- 必須変換確認パターン ---
required_patterns = {
    "TileEntityLockable": False,
    "ITickable": False,
    "EnumFacing": False,
    "NBTTagCompound": False,
    "EntityPlayer": False,
    "InventoryPlayer": False,
    "this.world": False,
    "furnaceItemStacks": False,
    "update()": False,
    "public void tick()": True,  # 必ずあるべき
}

def verify_file(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    result = {}
    for pattern, must_be_absent in required_patterns.items():
        if must_be_absent:
            result[pattern] = pattern in content
        else:
            result[pattern] = pattern not in content
    return result

def verify_all(folder):
    all_results = {}
    for file in os.listdir(folder):
        if file.endswith(".java"):
            path = os.path.join(folder, file)
            result = verify_file(path)
            all_results[file] = result
    return all_results

if __name__ == '__main__':
    results = verify_all(converted_folder)
    for filename, checks in results.items():
        print(f"\n[{filename}]")
        for key, passed in checks.items():
            status = "OK" if passed else "NG"
            print(f"  {key}: {status}")
