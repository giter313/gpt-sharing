import os
import re

def validate_message_class(file_content: str, filename: str) -> list:
    errors = []
    if not re.search(r'public static void encode\(', file_content):
        errors.append(f"{filename}: encode() が見つかりません")
    if not re.search(r'public static .*? decode\(', file_content):
        errors.append(f"{filename}: decode() が見つかりません")
    if not re.search(r'public static void handle\(', file_content):
        errors.append(f"{filename}: handle() が見つかりません")
    return errors

def validate_packet_handler(file_content: str, filename: str) -> list:
    errors = []
    if "SimpleChannel" not in file_content:
        errors.append(f"{filename}: SimpleChannel の宣言が見つかりません")
    register_matches = re.findall(r'registerMessage\((.+?)\);', file_content)
    for match in register_matches:
        if "::encode" not in match or "::decode" not in match or "::handle" not in match:
            errors.append(f"{filename}: registerMessage の形式が不完全 → {match}")
    return errors

def validate_converted_network_folder(folder_path: str):
    error_list = []
    for filename in os.listdir(folder_path):
        if not filename.endswith(".java"):
            continue

        file_path = os.path.join(folder_path, filename)
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

        if "SimpleChannel" in content and "registerMessage" in content:
            errors = validate_packet_handler(content, filename)
        else:
            errors = validate_message_class(content, filename)

        if errors:
            error_list.extend(errors)

    if error_list:
        print("❌ 検証エラーが見つかりました:")
        for err in error_list:
            print("  -", err)
    else:
        print("✅ すべてのファイルが正常に変換されています。")

# 実行
if __name__ == "__main__":
    validate_converted_network_folder("output_src/network")
