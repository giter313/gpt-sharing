import os
import re

input_dir = "input_src/render/npc"
output_dir = "output_src/render/npc"
os.makedirs(output_dir, exist_ok=True)

for filename in os.listdir(input_dir):
    if not filename.endswith(".java"):
        continue

    input_path = os.path.join(input_dir, filename)
    output_path = os.path.join(output_dir, filename)

    with open(input_path, 'r', encoding='utf-8') as f:
        code = f.read()

    # ========== 共通前処理 ==========

    # @SideOnly削除
    code = re.sub(r'@SideOnly\s*\(\s*Side\.CLIENT\s*\)', '', code)

    # GeoEntityRenderer import がなければ追加
    if 'GeoEntityRenderer' not in code:
        code = re.sub(
            r'(import\s+net\.minecraft[^\n]+;\s*)',
            r'\1import software.bernie.geckolib.renderer.GeoEntityRenderer;\n',
            code,
            count=1
        )

    # RenderLiving → GeoEntityRenderer
    code = re.sub(r'\bRenderLiving<([^>]+)>', r'GeoEntityRenderer<\1>', code)
    code = re.sub(r'extends\s+RenderLiving<([^>]+)>', r'extends GeoEntityRenderer<\1>', code)

    # Render<T> → GeoEntityRenderer<T>
    code = re.sub(r'\bRender<([^>]+)>', r'GeoEntityRenderer<\1>', code)
    code = re.sub(r'extends\s+Render<([^>]+)>', r'extends GeoEntityRenderer<\1>', code)

    # ========== OpenGL 警告 ==========

    code = re.sub(r'(\bGL1[12]\b\s*\.[^\n;]+)', r'// [WARNING] Deprecated OpenGL usage: \1', code)
    code = re.sub(r'(\bGlStateManager\b\s*\.[^\n;]+)', r'// [WARNING] Deprecated GlStateManager usage: \1', code)

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(code)

    print(f"[変換完了] {filename}")
