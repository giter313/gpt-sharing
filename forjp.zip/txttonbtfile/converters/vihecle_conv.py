import os
import re

INPUT_ROOT = "input_src/render/vehicle"
OUTPUT_ROOT = "output_src/render/vehicle"

def convert_render_file(filepath, relative_subpath):
    with open(filepath, 'r', encoding='utf-8') as f:
        code = f.read()

    class_match = re.search(r'public class (\w+)\s+extends RenderLiving<(\w+)>', code)
    if not class_match:
        print(f"[!] スキップ（RenderLiving継承クラスでない）: {filepath}")
        return
    old_class_name = class_match.group(1)
    entity_class_name = class_match.group(2)
    new_class_name = old_class_name.replace("Render", "")

    # クラス宣言変換
    code = re.sub(
        rf'public class {old_class_name}\s+extends RenderLiving<(\w+)>',
        f'public class {new_class_name} extends EntityRenderer<{entity_class_name}>',
        code
    )

    # コンストラクタ変換
    code = re.sub(
        rf'public {old_class_name}\(RenderManager renderManagerIn\)',
        f'public {new_class_name}(EntityRendererProvider.Context context)',
        code
    )
    code = re.sub(
        r'super\(renderManagerIn, .*?,.*?\);',
        f'super(context);',
        code
    )

    # OpenGL 警告コメント化
    code = re.sub(r'(GL11|GL12|GlStateManager)\.(\w+)', r'// [1.20.1 WARNING] \g<0>', code)

    # AdvancedModelLoader 対応
    code = re.sub(r'AdvancedModelLoader\.loadModel\((.*?)\)',
                  r'// [1.20.1 WARNING] AdvancedModelLoader は使用不可。GeckoLibなどに移行してください。\nnull',
                  code)

    # @SideOnly 削除
    code = re.sub(r'@SideOnly\(Side\.CLIENT\)\n', '', code)

    # getEntityTexture → getTextureLocation
    code = re.sub(
        r'protected ResourceLocation getEntityTexture\((.*?)\)',
        r'@Override\npublic ResourceLocation getTextureLocation(\1)',
        code
    )

    # doRender → render
    code = re.sub(
        r'public void doRender\((\w+ \w+), double x, double y, double z, float entityYaw, float partialTicks\)',
        r'@Override\npublic void render(\1, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource buffer, int packedLight)',
        code
    )

    # import の削除と追加
    code = re.sub(r'import org.lwjgl.opengl.GL11;', '// [REMOVED] import org.lwjgl.opengl.GL11;', code)
    code = re.sub(r'import org.lwjgl.opengl.GL12;', '// [REMOVED] import org.lwjgl.opengl.GL12;', code)
    code = re.sub(r'import net\.minecraft\.client\.renderer\.entity\.(RenderLiving|Render);', '// removed', code)

    imports = """
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
"""
    code = re.sub(r'(package .*?;\n)', r'\1' + imports + '\n', code)

    # 保存ディレクトリ作成
    out_dir = os.path.join(OUTPUT_ROOT, relative_subpath)
    os.makedirs(out_dir, exist_ok=True)

    filename = os.path.basename(filepath).replace("Render", "")
    with open(os.path.join(out_dir, filename), 'w', encoding='utf-8') as f:
        f.write(code)

    print(f"[✓] 変換完了: {relative_subpath}/{filename}")

def walk_and_convert():
    for root, dirs, files in os.walk(INPUT_ROOT):
        rel_path = os.path.relpath(root, INPUT_ROOT)
        for file in files:
            if file.endswith(".java"):
                convert_render_file(os.path.join(root, file), rel_path)

# 実行
walk_and_convert()
