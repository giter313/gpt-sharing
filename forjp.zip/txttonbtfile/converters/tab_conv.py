import os
import re

# 入出力ディレクトリの設定
INPUT_DIR = "input_src/tab"
OUTPUT_DIR = "output_src/tab"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# CreativeTabs → CreativeModeTab への変換テンプレート
def convert_creative_tab_code(class_name, icon_item, tab_label):
    return f'''package gvcr2.tab;

import gvcr2.mod_GVCR2;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class {class_name}Wrapper {{

    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS =
        DeferredRegister.create(ForgeRegistries.CREATIVE_MODE_TABS, mod_GVCR2.MODID);

    public static final RegistryObject<CreativeModeTab> {class_name.upper()} =
        CREATIVE_MODE_TABS.register("{class_name.lower()}", () ->
            CreativeModeTab.builder()
                .title(Component.translatable("itemGroup.{tab_label}"))
                .icon(() -> new ItemStack({icon_item}))
                .build()
        );

    public static void register() {{
        CREATIVE_MODE_TABS.register(FMLJavaModLoadingContext.get().getModEventBus());
    }}
}}
'''

# Javaファイルを1つずつ変換
def convert_file(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    class_match = re.search(r'public class (\w+)', content)
    icon_match = re.search(r'new ItemStack\(([\w\.]+)\)', content)

    if not class_match:
        print(f"❌ クラス名が見つかりません: {filepath}")
        return

    class_name = class_match.group(1)
    icon_item = icon_match.group(1) if icon_match else "Items.STONE"
    tab_label = "gvcr2." + class_name.lower()

    new_code = convert_creative_tab_code(class_name, icon_item, tab_label)

    output_file = os.path.join(OUTPUT_DIR, class_name + "Wrapper.java")
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(new_code)

    print(f"✅ 変換完了: {filepath} → {output_file}")

# 全ファイル変換実行
for filename in os.listdir(INPUT_DIR):
    if filename.endswith(".java"):
        convert_file(os.path.join(INPUT_DIR, filename))
