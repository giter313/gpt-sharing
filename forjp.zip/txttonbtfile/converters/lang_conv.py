import os
import json
from pathlib import Path

INPUT_DIR = Path("lang")
OUTPUT_DIR = Path("lang_output")
OUTPUT_DIR.mkdir(exist_ok=True)

def convert_lang_file(path: Path):
    translations = {}
    with path.open(encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                print(f"⚠️ 無効行: {line} in {path.name}")
                continue
            key, value = line.split("=", 1)
            translations[key.strip()] = value.strip()

    output_path = OUTPUT_DIR / (path.stem + ".json")
    with output_path.open("w", encoding="utf-8") as out:
        json.dump(translations, out, indent=2, ensure_ascii=False)
    print(f"✅ 変換完了: {path.name} → {output_path.name}")

def main():
    for file in INPUT_DIR.glob("*.lang"):
        convert_lang_file(file)

if __name__ == "__main__":
    main()
