#!/usr/bin/env python3

import os
import nbtlib
from nbtlib import Compound, List, Int, String

INPUT_FOLDER = "input/buildings"
OUTPUT_FOLDER = "output"

def get_palette_index(modid, block_id, meta, palette, palette_index):
    key = f"{modid}:{block_id}:{meta}"
    if key not in palette_index:
        state = {"Name": String(f"{modid}:{block_id}")}
        if meta != 0:
            state["Properties"] = Compound({"meta": String(str(meta))})
        palette_index[key] = len(palette)
        palette.append(Compound(state))
    return palette_index[key]

def convert_txt_file(filepath, output_path):
    blocks = []
    min_x = min_y = min_z = float('inf')
    max_x = max_y = max_z = float('-inf')

    with open(filepath, 'r', encoding='utf-8') as f:
        for lineno, line in enumerate(f, start=1):
            if line.startswith("Block"):
                try:
                    parts = line.strip().split(",")
                    if len(parts) != 7:
                        print(f"⚠️ 無視: {filepath}:{lineno} → カンマが {len(parts)} 個（期待: 7）")
                        continue
                    _, modid, block_id, x, y, z, meta = parts
                    x, y, z, meta = map(int, (x, y, z, meta))
                    blocks.append((modid, block_id, x, y, z, meta))
                    min_x = min(min_x, x); min_y = min(min_y, y); min_z = min(min_z, z)
                    max_x = max(max_x, x); max_y = max(max_y, y); max_z = max(max_z, z)
                except Exception as e:
                    print(f"❌ エラー行スキップ: {filepath}:{lineno} → {e}")

    if not blocks:
        print(f"⚠️ スキップ: {filepath}（Block定義なし）")
        return

    size_x = max_x - min_x + 1
    size_y = max_y - min_y + 1
    size_z = max_z - min_z + 1

    palette = []
    palette_index = {}
    block_data = []

    for modid, block_id, x, y, z, meta in blocks:
        px, py, pz = x - min_x, y - min_y, z - min_z
        pid = get_palette_index(modid, block_id, meta, palette, palette_index)
        block_data.append(Compound({"pos": List[Int]([px, py, pz]), "state": Int(pid)}))

    structure = Compound({
        "size": List[Int]([size_x, size_y, size_z]),
        "palette": List[Compound](palette),
        "blocks": List[Compound](block_data),
        "entities": List[Compound]([]),
        "author": String("ConvertedByScript"),
        "version": Int(1),
        "offset": List[Int]([-min_x, -min_y, -min_z])
    })

    os.makedirs(OUTPUT_FOLDER, exist_ok=True)
    filename_wo_ext = os.path.splitext(os.path.basename(filepath))[0]
    out_file = os.path.join(output_path, f"{filename_wo_ext}.nbt")
    nbtlib.File(structure).save(out_file)
    print(f"✅ 生成完了: {out_file}")

def main():
    if not os.path.exists(INPUT_FOLDER):
        print(f"❌ 入力フォルダが見つかりません: {INPUT_FOLDER}")
        return

    os.makedirs(OUTPUT_FOLDER, exist_ok=True)

    for filename in os.listdir(INPUT_FOLDER):
        if filename.endswith(".txt"):
            filepath = os.path.join(INPUT_FOLDER, filename)
            convert_txt_file(filepath, OUTPUT_FOLDER)

if __name__ == "__main__":
    main()
