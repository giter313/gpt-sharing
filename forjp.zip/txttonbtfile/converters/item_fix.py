import os
import json

# 対象ディレクトリ
TARGET_DIR = "itemoutput/models/item"

# 変換ログを格納
changed_files = []
skipped_files = []

def fix_texture_path(texture_path):
    # 例: gvcr2:items/spawn/gvcr2_spawn_air_mig17 → gvcr2:item/gvcr2_spawn_air_mig17
    if texture_path.startswith("gvcr2:items/"):
        return texture_path.replace("gvcr2:items/", "gvcr2:item/")
    return texture_path

def process_file(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        try:
            data = json.load(f)
        except json.JSONDecodeError:
            print(f"❌ JSONエラー: {filepath}")
            skipped_files.append(filepath)
            return

    if "textures" not in data or not isinstance(data["textures"], dict):
        skipped_files.append(filepath)
        return

    updated = False
    for key, value in data["textures"].items():
        new_value = fix_texture_path(value)
        if new_value != value:
            data["textures"][key] = new_value
            updated = True

    if updated:
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        changed_files.append(filepath)

def main():
    for root, _, files in os.walk(TARGET_DIR):
        for file in files:
            if file.endswith(".json"):
                process_file(os.path.join(root, file))

    print(f"\n✅ 修正済みファイル: {len(changed_files)} 件")
    for path in changed_files:
        print(f"  🔧 {path}")

    print(f"\n⚠️ スキップされたファイル: {len(skipped_files)} 件")
    for path in skipped_files:
        print(f"  ⚠️ {path}")

if __name__ == "__main__":
    main()
