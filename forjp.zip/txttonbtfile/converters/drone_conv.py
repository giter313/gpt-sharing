import os
import re

# === 変換対象と出力先フォルダのパスをここで指定 ===
input_folder = "input_src/render/drone"
output_folder = "output_src/render/drone"

# === Javaコード全体を変換する関数 ===
def convert_java_content(java_code: str) -> str:
    # RenderLiving を MobRenderer に変更
    java_code = re.sub(r'extends\s+RenderLiving<([^>]+)>', r'extends MobRenderer<\1, ModelBase_Non>', java_code)

    # import の修正
    java_code = java_code.replace(
        'net.minecraft.client.renderer.entity.RenderLiving',
        'net.minecraft.client.renderer.entity.MobRenderer'
    )
    if 'import net.minecraft.client.renderer.entity.Render;' in java_code:
        java_code = java_code.replace(
            'import net.minecraft.client.renderer.entity.Render;\n', ''
        )

    # doRender → render に名前変更
    java_code = re.sub(r'public void doRender\(([^)]+)\)', r'@Override\n    public void render(\1)', java_code)

    # doRender 呼び出しを super.render に変換
    java_code = re.sub(r'super\.doRender\(([^)]+)\)', r'super.render(\1)', java_code)

    # bindEntityTexture 削除（getEntityTexture に依存する）
    java_code = re.sub(r'\s*this\.bindEntityTexture\(.*?\);\s*', '', java_code)

    # Shadow size を shadowRadius に変換（Forge 1.20.1ではフィールド名が違う）
    java_code = re.sub(r'this\.shadowSize', 'this.shadowRadius', java_code)

    return java_code

# === フォルダを一括処理 ===
def convert_folder(input_path: str, output_path: str):
    os.makedirs(output_path, exist_ok=True)
    for filename in os.listdir(input_path):
        if filename.endswith(".java"):
            in_file = os.path.join(input_path, filename)
            out_file = os.path.join(output_path, filename)
            with open(in_file, "r", encoding="utf-8") as f:
                original_code = f.read()
            converted_code = convert_java_content(original_code)
            with open(out_file, "w", encoding="utf-8") as f:
                f.write(converted_code)
            print(f"✅ {filename} を変換しました")

# === 実行 ===
if __name__ == "__main__":
    convert_folder(input_folder, output_folder)
