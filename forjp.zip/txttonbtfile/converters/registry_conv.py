import os
import re

def convert_registry_java_to_modern(file_content: str, file_name: str):
    output_lines = []

    # 変換対象関数
    shaped_recipe_pattern = re.compile(r'GameRegistry\.addShapedRecipe\s*\((.*?)\);\s*', re.DOTALL)
    smelting_pattern = re.compile(r'GameRegistry\.addSmelting\s*\((.*?)\);\s*', re.DOTALL)

    # ファイル全体を処理
    converted = file_content

    # ShapedRecipe の除去とコメント化
    def shaped_repl(match):
        body = match.group(1)
        return f"// Converted shaped recipe removed: GameRegistry.addShapedRecipe({body});"

    converted = shaped_recipe_pattern.sub(shaped_repl, converted)

    # Smelting の除去とコメント化
    def smelting_repl(match):
        body = match.group(1)
        return f"// Converted smelting recipe removed: GameRegistry.addSmelting({body});"

    converted = smelting_pattern.sub(smelting_repl, converted)

    # 必要な警告・注釈を挿入
    header_comment = (
        f"// [!] This file '{file_name}' was auto-converted from Minecraft Forge 1.12.2 to 1.20.1.\n"
        "// [!] Manual replacement needed:\n"
        "//     - Replace removed GameRegistry.addShapedRecipe with JSON files in 'resources/data/...' directory.\n"
        "//     - Replace removed GameRegistry.addSmelting with JSON or custom smelting registration code.\n\n"
    )

    return header_comment + converted


def convert_registry_folder(folder_path: str, output_path: str):
    if not os.path.exists(output_path):
        os.makedirs(output_path)

    for filename in os.listdir(folder_path):
        if filename.endswith(".java"):
            input_file = os.path.join(folder_path, filename)
            output_file = os.path.join(output_path, filename)

            with open(input_file, "r", encoding="utf-8") as f:
                content = f.read()

            converted_content = convert_registry_java_to_modern(content, filename)

            with open(output_file, "w", encoding="utf-8") as f:
                f.write(converted_content)

            print(f"Converted: {filename}")


# 使用例
if __name__ == "__main__":
    input_registry_folder = "input_src/registry"       # 入力フォルダ（Forge 1.12.2）
    output_registry_folder = "output_src/registry"  # 出力フォルダ（1.20.1形式に変換）

    convert_registry_folder(input_registry_folder, output_registry_folder)
