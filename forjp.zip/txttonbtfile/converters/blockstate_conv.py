import json
import os
from pathlib import Path

INPUT_DIR = Path("blockstate_input")
OUTPUT_DIR = Path("blockstate_output")
OUTPUT_DIR.mkdir(exist_ok=True)

MODID = "gvcr2"


def is_valid_variant_entry(entry):
    return isinstance(entry, dict) and "model" in entry and isinstance(
        entry["model"], str)


def fix_model_path(model_path: str) -> str:
    if ":" not in model_path:
        return f"{MODID}:{model_path}"
    return model_path


def process_blockstate_file(path: Path):
    try:
        with path.open(encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print(f"🚫 JSON読み込み失敗: {path} → {e}")
        return

    if "variants" not in data:
        print(f"⚠️ 無視: {path.name}（variantsなし）")
        return

    updated = False
    new_variants = {}

    for state, entry in data["variants"].items():
        if isinstance(entry, list):
            fixed_entries = []
            for e in entry:
                if is_valid_variant_entry(e):
                    new_model = fix_model_path(e["model"])
                    if new_model != e["model"]:
                        updated = True
                        e["model"] = new_model
                    fixed_entries.append(e)
            new_variants[state] = fixed_entries
        elif is_valid_variant_entry(entry):
            new_model = fix_model_path(entry["model"])
            if new_model != entry["model"]:
                updated = True
                entry["model"] = new_model
            new_variants[state] = entry
        else:
            print(f"⚠️ 無効エントリ: {path.name} の {state}")
            new_variants[state] = entry  # 保守的に維持

    data["variants"] = new_variants
    out_path = OUTPUT_DIR / path.name
    with out_path.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

    if updated:
        print(f"✅ 修正・出力: {path.name}")
    else:
        print(f"🆗 問題なし → コピー出力: {path.name}")


def main():
    for file in INPUT_DIR.glob("*.json"):
        process_blockstate_file(file)


if __name__ == "__main__":
    main()
