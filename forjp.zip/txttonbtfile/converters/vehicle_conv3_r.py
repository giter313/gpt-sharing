import os
import re

# === 設定 ===
base_dir = "input_src/render/vehicle"  # 実際のパスに置き換えてください
target_subfolders = ["air", "apc", "car", "ge", "heli", "robo", "set", "ship","tank"]
output_base_dir = "output_src/render/vehicle"  # 実際の出力先に置き換えてください
log_file_path = "convert_log.txt"
gl_warning = "// TODO: OpenGL(GL11/GL12)は1.20.1では非推奨、代替方法を検討"

# ログ用リスト
log_lines = []


def log(message):
    print(message)
    log_lines.append(message)


def convert_render_file(content):
    changed = False
    new_content = content

    # Render<> または RenderLiving<> 継承を検出してコメント追加
    if re.search(r"extends\s+Render(?:Living)?<[^>]+>", content):
        new_content = re.sub(
            r"(extends\s+Render(?:Living)?<[^>]+>)",
            r"\1\n// TODO: Forge 1.20.1 対応のために描画APIを確認・調整する必要があります。",
            new_content)
        changed = True

    # GL11/GL12 の使用行に警告を挿入
    def add_gl_comment(match):
        return f"{gl_warning}\n{match.group(1)}"

    if re.search(r"\bGL1[12]\.", content):
        new_content = re.sub(r"^(.*\bGL1[12]\..*)$",
                             add_gl_comment,
                             new_content,
                             flags=re.MULTILINE)
        changed = True

    return new_content if changed else None


# === メイン処理 ===
for subfolder in target_subfolders:
    input_dir = os.path.join(base_dir, subfolder)
    output_dir = os.path.join(output_base_dir, subfolder)
    os.makedirs(output_dir, exist_ok=True)

    if not os.path.exists(input_dir):
        log(f"❌ Folder not found: {input_dir}")
        continue

    for filename in os.listdir(input_dir):
        if filename.endswith(".java"):
            input_path = os.path.join(input_dir, filename)
            output_path = os.path.join(output_dir, filename)
            try:
                with open(input_path, "r", encoding="utf-8") as f:
                    content = f.read()

                converted = convert_render_file(content)
                if converted:
                    with open(output_path, "w", encoding="utf-8") as f:
                        f.write(converted)
                    log(f"✅ Converted: {input_path}")
                else:
                    log(f"⚠️ Skipped:   {input_path}（Render/GL 使用なし）")
            except Exception as e:
                log(f"❌ Error:     {input_path}（{e}）")

# === ログ書き出し ===
with open(log_file_path, "w", encoding="utf-8") as log_file:
    log_file.write("\n".join(log_lines))

print(f"\n📄 ログ出力完了: {log_file_path}")
