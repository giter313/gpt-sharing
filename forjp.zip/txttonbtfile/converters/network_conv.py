import os
import re

# チャンネル変換関数
def convert_packet_handler_java(file_content: str, class_name: str) -> str:
    channel_matches = re.findall(r'public static final SimpleNetworkWrapper (\w+) = NetworkRegistry.INSTANCE.newSimpleChannel\((.+?)\);', file_content)
    channel_decls = []
    register_calls = []

    for i, (channel_var, channel_id_raw) in enumerate(channel_matches):
        channel_id = re.sub(r'(\"|\')|\s', '', channel_id_raw)
        channel_id_name = channel_id.replace("+", "_").replace("\"", "").replace("'", "")
        channel_name = f"CHANNEL_{i}"

        channel_decls.append(f'''\
    public static final SimpleChannel {channel_name} = NetworkRegistry.ChannelBuilder
        .named(new ResourceLocation(ModGVCR2.MODID, "{channel_id_name.lower()}"))
        .networkProtocolVersion(() -> "1.0")
        .clientAcceptedVersions(s -> true)
        .serverAcceptedVersions(s -> true)
        .simpleChannel();''')

        pattern = re.compile(rf'{channel_var}\.registerMessage\((.*?),\s*(.*?),\s*(\d+),\s*Side\.(SERVER|CLIENT)\);')
        for match in pattern.finditer(file_content):
            handler, message, idx, side = match.groups()
            direction = "NetworkDirection.PLAY_TO_SERVER" if side == "SERVER" else "NetworkDirection.PLAY_TO_CLIENT"
            register_calls.append(f'''\
        {channel_name}.registerMessage({idx}, {message}.class,
            {message}::encode,
            {message}::decode,
            {message}::handle,
            Optional.of({direction})
        );''')

    imports = '''\
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.SimpleChannel;
import net.minecraftforge.network.NetworkDirection;
import net.minecraft.resources.ResourceLocation;
import java.util.Optional;
'''

    return f'''\
package gvcr2.network;

import gvcr2.ModGVCR2;
{imports}

public class {class_name} {{

{chr(10).join(channel_decls)}

    public static void register() {{
{chr(10).join(register_calls)}
    }}
}}
'''

# メッセージクラス変換
def convert_message_class(file_content: str, class_name: str) -> str:
    if "decode" in file_content and "encode" in file_content and "handle" in file_content:
        return file_content  # すでに変換済み

    body = f'''\
    public static void encode({class_name} msg, FriendlyByteBuf buf) {{
        // TODO: データを書き込み
    }}

    public static {class_name} decode(FriendlyByteBuf buf) {{
        // TODO: データ読み取り
        return new {class_name}();
    }}

    public static void handle({class_name} msg, Supplier<NetworkEvent.Context> ctx) {{
        ctx.get().enqueueWork(() -> {{
            // TODO: 処理内容
        }});
        ctx.get().setPacketHandled(true);
    }}
'''

    imports = '''\
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;
'''

    package_match = re.search(r'package .*?;', file_content)
    package_decl = package_match.group(0) if package_match else "package gvcr2.network;"

    return f'''\
{package_decl}

{imports}

public class {class_name} {{

{body}
}}
'''

# フォルダ一括変換
def convert_network_folder(input_folder: str, output_folder: str):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    for filename in os.listdir(input_folder):
        if not filename.endswith(".java"):
            continue

        with open(os.path.join(input_folder, filename), "r", encoding="utf-8") as f:
            content = f.read()

        class_match = re.search(r'public class (\w+)', content)
        if not class_match:
            continue
        class_name = class_match.group(1)

        # PacketHandler クラス
        if "SimpleNetworkWrapper" in content:
            converted = convert_packet_handler_java(content, class_name)
        # Message クラス
        else:
            converted = convert_message_class(content, class_name)

        output_path = os.path.join(output_folder, filename)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(converted)
        print(f"変換完了: {filename} → {output_path}")

# 実行部分（入力と出力をパスで指定）
if __name__ == "__main__":
    input_path = "input_src/network"         # 入力フォルダ（1.12.2）
    output_path = "output_src/network"  # 出力フォルダ（1.20.1）

    convert_network_folder(input_path, output_path)
