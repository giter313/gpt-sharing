import os
import re

# ------------------------
# 変換ルール定義
# ------------------------
REPLACEMENTS = {
    "entity": [
        (r'\bEntityLivingBase\b', 'LivingEntity'),
        (r'\bEntityPlayer\b', 'Player'),
        (r'getItemStackFromSlot\s*\(', 'getItemBySlot('),
        (r'world\.spawnEntity\s*\(', 'level.addFreshEntity('),
        (r'world\.playSound\s*\(', 'level.playSound('),
        (r'@SubscribeEvent', '@Mod.EventBusSubscriber'),
        (r'EntityJoinWorldEvent', 'EntityJoinWorldEvent'),  # 引数名修正は手動対応
        (r'NBTTagCompound', 'CompoundTag'),
    ],
    "item": [
        (r'\bItemStack\b', 'net.minecraft.world.item.ItemStack'),
        (r'addInformation\s*\(', 'appendHoverText('),
        (r'ITextComponent', 'Component.literal'),
        (r'event\.setCanceled\(true\)', 'event.setCancellationResult(InteractionResult.SUCCESS)'),
        (r'world\.isRemote', 'level.isClientSide()'),
        (r'GameRegistry\.register\s*\(', '// DeferredRegisterを使用してください'),
        (r'Item#getMetadata\s*\(\)', 'ItemStack#getDamageValue()'),
        (r'NBTTagCompound', 'CompoundTag'),
    ],
    "level": [
        (r'\bWorld\b', 'Level'),
        (r'WorldTickEvent', 'LevelTickEvent'),
        (r'World#setDifficulty\s*\(', 'ServerLevel#setDifficulty('),
        (r'WorldSavedData', 'SavedData'),
        (r'world.getTotalWorldTime\s*\(\)', 'level.getGameTime()'),
        (r'Configuration', 'ModConfig'),
        (r'NBTTagCompound', 'CompoundTag'),
    ],
    "world": [
        (r'WorldEvent\.Load', 'LevelEvent.Load'),
        (r'EntityJoinWorldEvent', 'EntityJoinWorldEvent'),
        (r'\bWorld\b', 'Level'),
        (r'World#setWorldTime\s*\(', 'Level#setDayTime('),
        (r'ResourceLocation\("([^"]+)"\)', r'ResourceLocation("modid", "\1")'),
        (r'WorldSavedData', 'SavedData'),
        (r'NBTTagCompound', 'CompoundTag'),
    ],
}

# ------------------------
# ファイル変換処理
# ------------------------
def convert_event_folder_112_to_120(base_input_dir, base_output_dir):
    event_dir = os.path.join(base_input_dir, "event")
    output_event_dir = os.path.join(base_output_dir, "event")
    os.makedirs(output_event_dir, exist_ok=True)

    for subfolder, replacements in REPLACEMENTS.items():
        input_subdir = os.path.join(event_dir, subfolder)
        output_subdir = os.path.join(output_event_dir, subfolder)
        if not os.path.exists(input_subdir):
            print(f"[スキップ] フォルダが存在しません: {input_subdir}")
            continue
        os.makedirs(output_subdir, exist_ok=True)

        for filename in os.listdir(input_subdir):
            if not filename.endswith(".java"):
                continue

            input_path = os.path.join(input_subdir, filename)
            output_path = os.path.join(output_subdir, filename)

            with open(input_path, "r", encoding="utf-8") as f:
                content = f.read()

            for pattern, replacement in replacements:
                content = re.sub(pattern, replacement, content)

            if subfolder == "entity" and "Capability" in content:
                content = "// TODO: Capability API（LazyOptional）に手動対応が必要です\n" + content

            with open(output_path, "w", encoding="utf-8") as f:
                f.write(content)

            print(f"[変換完了] {subfolder}/{filename}")

# ------------------------
# 実行部分
# ------------------------
if __name__ == "__main__":
    # 入力と出力のルートディレクトリ（必要に応じて変更可能）
    input_root = "input_src"
    output_root = "output_src"

    convert_event_folder_112_to_120(input_root, output_root)
    print("\n✅ 変換が完了しました。出力先: output/src/gvcr2/event/")
