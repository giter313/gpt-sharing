import os
import re

# 🔧 入力フォルダと出力フォルダをここで指定
input_folder = "input_src/render/mob"
output_folder = "output_src/render/mob"

# フォルダ作成（存在しない場合）
os.makedirs(output_folder, exist_ok=True)

# 変換処理の定義
def convert_java_code(code: str) -> str:
    # RenderLiving → MobRenderer
    code = re.sub(r'\bRenderLiving<', 'MobRenderer<', code)
    code = re.sub(r'\bRenderLiving\b', 'MobRenderer', code)

    # RenderManager → EntityRendererProvider.Context
    code = re.sub(r'\bRenderManager\b', 'EntityRendererProvider.Context', code)

    # doRender メソッド名 → render に置換（内容そのまま）
    code = re.sub(
        r'(public\s+void\s+)doRender\s*\(',
        r'\1render(',
        code
    )

    # 必要な import を追加（重複回避）
    if "MobRenderer<" in code and "import net.minecraft.client.renderer.entity.MobRenderer;" not in code:
        code = code.replace(
            'import net.minecraft.client.renderer.entity.RenderLiving;',
            'import net.minecraft.client.renderer.entity.MobRenderer;'
        )

    if "EntityRendererProvider.Context" in code and "import net.minecraft.client.renderer.entity.EntityRendererProvider;" not in code:
        code = re.sub(r'(import\s+net\.minecraft\.client\.renderer\.entity\..*?;)', 
                      r'\1\nimport net.minecraft.client.renderer.entity.EntityRendererProvider;', 
                      code, 1)

    return code

# 全ファイル変換
def convert_folder(input_path: str, output_path: str):
    for filename in os.listdir(input_path):
        if filename.endswith(".java"):
            in_file = os.path.join(input_path, filename)
            out_file = os.path.join(output_path, filename)

            with open(in_file, "r", encoding="utf-8") as f:
                original_code = f.read()

            converted_code = convert_java_code(original_code)

            with open(out_file, "w", encoding="utf-8") as f:
                f.write(converted_code)
            print(f"✅ 変換完了: {filename}")

# 実行
if __name__ == "__main__":
    print(f"📂 入力: {input_folder}")
    print(f"📁 出力: {output_folder}")
    convert_folder(input_folder, output_folder)
