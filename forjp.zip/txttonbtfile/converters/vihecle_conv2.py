#!/usr/bin/env python3
import os
import re
from pathlib import Path

INPUT_DIR = Path("input_src/render/vehicle")
OUTPUT_DIR = Path("out_tests/vehicle")

# 対象フォルダ一覧
SUBFOLDERS = ["air", "apc", "car", "ge", "heli", "robo", "set", "ship", "tank"]

# 出力用関数
def convert_render_java(java_code: str) -> str:
    class_name = re.search(r"class (Render\w+)", java_code)
    entity_class = re.search(r"Render<([\w\.]+)>", java_code)
    if not class_name or not entity_class:
        return None  # Render<> を継承していない場合は除外

    name = class_name.group(1)
    entity = entity_class.group(1).split(".")[-1]  # 最後の部分だけ抽出

    lines = java_code.splitlines()

    output_lines = []
    for line in lines:
        if 'GL11.' in line or 'GL12.' in line or 'GlStateManager.' in line:
            continue  # OpenGL命令は削除
        if 'AdvancedModelLoader' in line or 'IModelCustom' in line:
            continue  # モデルロードは削除（使用方法により個別対応）
        if 'bindTexture' in line or 'bindEntityTexture' in line:
            continue
        if 'RenderBomber_Target' in line or 'RenderCanMobRidding' in line:
            continue
        if re.search(r"gl(Enable|Disable|PushMatrix|PopMatrix|Translatef|Rotatef|Color4f)", line):
            continue
        output_lines.append(line)

    converted_code = '\n'.join(output_lines)
    converted_code += f"\n\n// NOTE: Converted {name} for {entity}\n"
    return converted_code


def process_all():
    count_converted = 0
    count_skipped = 0

    for sub in SUBFOLDERS:
        input_path = INPUT_DIR / sub
        output_path = OUTPUT_DIR / sub
        output_path.mkdir(parents=True, exist_ok=True)

        for file in input_path.glob("*.java"):
            java_code = file.read_text(encoding="utf-8")
            converted = convert_render_java(java_code)
            if converted is None:
                print(f"[!] スキップ（Render<>継承でない）: {file}")
                count_skipped += 1
                continue
            (output_path / file.name).write_text(converted, encoding="utf-8")
            print(f"[✓] 変換完了: {file}")
            count_converted += 1

    print(f"\n[✔] 総変換数: {count_converted} 件")
    print(f"[!] スキップ数: {count_skipped} 件")


if __name__ == "__main__":
    process_all()
