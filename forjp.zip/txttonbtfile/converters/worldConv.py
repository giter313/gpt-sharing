import os
import re

# --- 設定 ---
INPUT_DIR = "input_src/world"
OUTPUT_DIR = "output_src/world"

# --- ユーティリティ ---
def convert_file_content(content):
    # 1. IWorldGenerator 削除
    content = re.sub(r"implements\s+IWorldGenerator", "", content)

    # 2. World → Level
    content = re.sub(r"\bWorld\b", "Level", content)

    # 3. BlockPos まわり（念のため）
    content = re.sub(r"new\s+BlockPos\((.*?)\)", r"BlockPos.of(\1)", content)

    # 4. setBlockState → setBlock
    content = re.sub(r"\.setBlockState\(([^,]+),\s*([^,]+)\)", r".setBlock(\1, \2, 3)", content)

    # 5. GameRegistry.registerWorldGenerator → 削除 & コメント
    content = re.sub(
        r"GameRegistry\.registerWorldGenerator\([^)]+\);",
        "// [REMOVED] World generator registration is replaced in 1.20.1",
        content
    )

    # 6. ChunkPrimer 警告
    if "ChunkPrimer" in content:
        content = "// [WARNING] ChunkPrimer no longer exists in 1.20.1\n" + content

    return content

# --- メイン処理 ---
def convert_world_java_files():
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)

    for filename in os.listdir(INPUT_DIR):
        if filename.endswith(".java"):
            input_path = os.path.join(INPUT_DIR, filename)
            output_path = os.path.join(OUTPUT_DIR, filename)

            with open(input_path, "r", encoding="utf-8") as f:
                content = f.read()

            converted = convert_file_content(content)

            with open(output_path, "w", encoding="utf-8") as f:
                f.write(converted)

            print(f"変換完了: {filename}")

# --- 実行 ---
if __name__ == "__main__":
    convert_world_java_files()
