import os
import re
import json
from pathlib import Path
import anvil  # pip install anvil-parser

INPUT_FOLDER = "input/buildings"
OUTPUT_FOLDER = "output"

# ブロックIDの構築（必要に応じて1.20.1の形式に変換）
def build_block_id(namespace, name, meta=0):
    return f"{namespace}:{name}[meta={meta}]" if meta != 0 else f"{namespace}:{name}"

# TileEntity付きかどうか判定
def is_tile_block(tokens):
    return len(tokens) > 7 and len(tokens[7:]) % 2 == 0

# メイン変換関数
def convert_txt_file(filepath, output_dir):
    filename = Path(filepath).stem
    output_path = os.path.join(output_dir, f"{filename}.nbt")

    block_data = []
    tile_entities = []

    with open(filepath, "r", encoding="utf-8") as f:
        for lineno, line in enumerate(f, 1):
            line = line.strip()
            if not line or line.startswith("#"):
                continue

            tokens = line.split(",")
            if tokens[0] != "Block":
                continue

            if len(tokens) < 7:
                print(f"⚠️ 無視: {filepath}:{lineno} → カンマ数不足（{len(tokens)}）")
                continue

            try:
                namespace = tokens[1]
                block_name = tokens[2]
                x, y, z = map(int, tokens[3:6])
                meta = int(tokens[6])

                block_id = build_block_id(namespace, block_name, meta)

                block_data.append({
                    "Name": f"{namespace}:{block_name}",
                    "x": x,
                    "y": y,
                    "z": z,
                    "Properties": {
                        "meta": str(meta)
                    }
                })

                # TileEntity付き
                if is_tile_block(tokens):
                    tile_items = tokens[7:]
                    items = []
                    for i in range(0, len(tile_items), 2):
                        item_id = tile_items[i]
                        count = int(tile_items[i+1])
                        items.append({
                            "id": item_id,
                            "Count": count
                        })

                    tile_entities.append({
                        "id": "minecraft:chest",
                        "x": x,
                        "y": y,
                        "z": z,
                        "Items": items
                    })

            except Exception as e:
                print(f"⚠️ 無視: {filepath}:{lineno} → エラー: {e}")
                continue

    # 出力フォルダ作成
    os.makedirs(output_dir, exist_ok=True)

    # anvilセクション構築（仮のNBT形式、MCEdit用）
    level = {
        "blocks": block_data,
        "tile_entities": tile_entities
    }

    with open(output_path, "w", encoding="utf-8") as out:
        json.dump(level, out, indent=2)

    print(f"✅ 生成完了: {output_path}")

# 全ファイル一括変換
def main():
    for root, _, files in os.walk(INPUT_FOLDER):
        for file in files:
            if file.endswith(".txt"):
                filepath = os.path.join(root, file)
                convert_txt_file(filepath, OUTPUT_FOLDER)

if __name__ == "__main__":
    main()
