import os
import re

# 対象のディレクトリ（変換済みファイル群）
converted_base_dir = "output_src/render/vehicle"  # 実際のパスに置き換えてください
log_file_path = "verify_compatibility_log.txt"

# Forge 1.20.1 の特徴的なクラス
expected_keywords_1_20_1 = [
    "EntityRendererProvider", "MultiBufferSource", "PoseStack",
    "RenderType", "RenderTypeEntityRenderer", "EntityRenderer", "ResourceLocation"
]

# ログ出力
log_lines = []

def log(msg):
    print(msg)
    log_lines.append(msg)

def verify_java_file(file_path):
    issues = []
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()

    # 古いAPIの使用チェック
    if re.search(r"\bRender(?:Living)?<", content):
        issues.append("❌ Render/RenderLiving の使用（非推奨）")

    if "GL11." in content or "GL12." in content:
        issues.append("⚠️ OpenGL(GL11/12) の直接使用")

    if "// TODO: Forge 1.20.1 対応のために描画APIを確認・調整する必要があります。" not in content:
        issues.append("⚠️ 変換用コメントが不足している")

    if not any(keyword in content for keyword in expected_keywords_1_20_1):
        issues.append("⚠️ 1.20.1 の典型APIが検出されない（変換漏れの可能性）")

    if issues:
        log(f"\n[⚠️ CHECK] {file_path}")
        for issue in issues:
            log(f"  - {issue}")
    else:
        log(f"\n[✅ OK] {file_path}")

# 再帰的に Java ファイルをチェック
for root, _, files in os.walk(converted_base_dir):
    for filename in files:
        if filename.endswith(".java"):
            full_path = os.path.join(root, filename)
            try:
                verify_java_file(full_path)
            except Exception as e:
                log(f"\n[❌ ERROR] {full_path}\n  - 読み込み失敗: {e}")

# ログファイル書き出し
with open(log_file_path, "w", encoding="utf-8") as f:
    f.write("\n".join(log_lines))

print(f"\n📄 チェック完了。ログを {log_file_path} に出力しました。")
