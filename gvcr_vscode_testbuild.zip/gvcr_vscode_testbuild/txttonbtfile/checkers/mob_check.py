import os
import re
import sys

# 🔧 コマンドライン引数 or デフォルトパスを使う
check_folder = sys.argv[1] if len(sys.argv) > 1 else "output_src/render/mob"

# 🔍 チェックパターン（1.20.1では非推奨または使用不可）
checks = [
    (r'\bRenderLiving\b', "❌ RenderLiving が残っています（MobRenderer に変換すべき）"),
    (r'\bRenderManager\b', "❌ RenderManager が残っています（EntityRendererProvider.Context にすべき）"),
    (r'\bdoRender\s*\(', "❌ doRender メソッドが残っています（render に変換すべき）"),
    (r'@SideOnly\s*\(', "❌ @SideOnly アノテーションが残っています"),
    (r'import\s+net\.minecraftforge\.fml\.relauncher\.', "❌ FML relauncher 関連の import が残っています"),
    (r'\bGL11\b|\bGL12\b', "⚠️ GL11 / GL12 の命令が残っています（PoseStack に変える必要あり）"),
    (r'\bgetEntityTexture\b', "❌ getEntityTexture が残っています（getTextureLocation にすべき）"),
]

def check_java_code(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        code = f.read()
    results = []
    for pattern, message in checks:
        if re.search(pattern, code):
            results.append(message)
    return results

def check_folder_java_files(folder):
    if not os.path.exists(folder):
        print(f"❗ 指定されたフォルダが存在しません: {folder}")
        return
    print(f"\n🔎 チェック開始: {folder}")
    error_found = False
    for filename in os.listdir(folder):
        if filename.endswith(".java"):
            file_path = os.path.join(folder, filename)
            issues = check_java_code(file_path)
            if issues:
                print(f"\n[!] {filename}:")
                for issue in issues:
                    print("   -", issue)
                error_found = True
    if not error_found:
        print("✅ すべてのファイルが Forge 1.20.1 に準拠しているようです。")

if __name__ == "__main__":
    check_folder_java_files(check_folder)
