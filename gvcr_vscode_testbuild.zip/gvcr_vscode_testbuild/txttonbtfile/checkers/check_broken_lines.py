import os

INPUT_FOLDER = "input/buildings"

def check_broken_lines():
    if not os.path.exists(INPUT_FOLDER):
        print(f"❌ 入力フォルダが見つかりません: {INPUT_FOLDER}")
        return

    for filename in os.listdir(INPUT_FOLDER):
        if not filename.endswith(".txt"):
            continue
        filepath = os.path.join(INPUT_FOLDER, filename)
        with open(filepath, "r", encoding="utf-8") as f:
            for lineno, line in enumerate(f, start=1):
                if line.startswith("Block"):
                    parts = line.strip().split(",")
                    if len(parts) != 7:
                        print(f"⚠️ 壊れた行: {filename}:{lineno} → '{line.strip()}' （カンマ数: {len(parts)}）")

if __name__ == "__main__":
    check_broken_lines()
