import os
import re

# ====== 設定 ======
target_folder = "output_src/render/tile"  # 変換後のJavaファイルが入っているフォルダ

def check_tile_renderer(java_code: str, filename: str) -> list:
    issues = []

    # 1. implements BlockEntityRenderer<T>
    if not re.search(r'implements\s+BlockEntityRenderer<[\w\d_]+>', java_code):
        issues.append("❌ BlockEntityRenderer<T> を implements していません。")

    # 2. import チェック
    if 'import net.minecraft.client.renderer.blockentity.BlockEntityRenderer' not in java_code:
        issues.append("❌ BlockEntityRenderer の import がありません。")

    # 3. render メソッドの引数形式
    if not re.search(r'public void render\s*\(\s*[\w\d_]+ te,\s*float partialTick,\s*PoseStack\b.*?MultiBufferSource\b.*?\)', java_code, re.DOTALL):
        issues.append("❌ render メソッドの引数が Forge 1.20.1 形式ではありません。")

    # 4. Minecraft.getInstance() に修正されているか
    if 'Minecraft.getInstance()' not in java_code:
        issues.append("⚠️ Minecraft.getInstance() が使われていません。古い getMinecraft() のままかもしれません。")

    # 5. SideOnly が残っていないか
    if '@SideOnly' in java_code:
        issues.append("⚠️ @SideOnly が残っています。Forge 1.20.1では不要です。")

    return issues


def check_all_tile_renderers():
    print(f"🔍 TileEntityRenderer 検証: {target_folder}\n")
    for filename in os.listdir(target_folder):
        if filename.endswith(".java"):
            filepath = os.path.join(target_folder, filename)
            with open(filepath, "r", encoding="utf-8") as f:
                java_code = f.read()

            issues = check_tile_renderer(java_code, filename)
            if issues:
                print(f"❗ {filename} に問題があります:")
                for issue in issues:
                    print(f"   {issue}")
                print()
            else:
                print(f"✅ {filename} は正しく変換されています。")

    print("\n✔️ 検証完了。")


if __name__ == "__main__":
    check_all_tile_renderers()
