import os
import re

# チェック対象ディレクトリ
OUTPUT_DIR = "output_src/tab"

# チェック結果表示関数
def check_file(filepath):
    results = {
        "filename": os.path.basename(filepath),
        "has_creative_mode_tab": False,
        "has_registry_object": False,
        "has_deferred_register": False,
        "has_title": False,
        "has_icon": False,
        "has_register_method": False
    }

    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # 各種パターン検出
    if "CreativeModeTab" in content:
        results["has_creative_mode_tab"] = True
    if "RegistryObject<CreativeModeTab>" in content:
        results["has_registry_object"] = True
    if "DeferredRegister.create(ForgeRegistries.CREATIVE_MODE_TABS" in content:
        results["has_deferred_register"] = True
    if ".title(" in content:
        results["has_title"] = True
    if ".icon(" in content:
        results["has_icon"] = True
    if "register(FMLJavaModLoadingContext" in content:
        results["has_register_method"] = True

    return results

# 全ファイルチェック
def check_all_files():
    print("=== Forge 1.20.1 対応 Creative Tab 構造チェック ===\n")
    for filename in os.listdir(OUTPUT_DIR):
        if not filename.endswith(".java"):
            continue
        filepath = os.path.join(OUTPUT_DIR, filename)
        result = check_file(filepath)
        print(f"🔍 {result['filename']}")
        for key, val in result.items():
            if key != "filename":
                mark = "✅" if val else "❌"
                print(f"  {mark} {key}")
        print()

# 実行
if __name__ == "__main__":
    check_all_files()
