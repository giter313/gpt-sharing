import os
import re

# ======= 設定（変換済みの .java ファイルを格納したフォルダ）=======
converted_dir = "output_src/world"  # 必要に応じて変更

# ======= チェック項目 =======
checks = {
    "package_declaration": re.compile(r"^\s*package\s+[\w\.]+;", re.MULTILINE),
    "class_declaration": re.compile(r"\b(public\s+)?(class|record|interface)\s+\w+", re.MULTILINE),
    "no_old_imports": re.compile(r"net\.minecraftforge\.fml\.common", re.MULTILINE),
    "valid_imports": re.compile(r"import\s+net\.minecraft\.", re.MULTILINE),
    "no_errors_left": re.compile(r"TODO|FIXME|@Override\s+//\s*missing", re.MULTILINE),
}

# ======= 結果保存用 =======
results = {}

# ======= フォルダ存在確認 =======
if not os.path.exists(converted_dir):
    print(f"[エラー] 指定されたディレクトリが存在しません: {converted_dir}")
else:
    for filename in os.listdir(converted_dir):
        if filename.endswith(".java"):
            filepath = os.path.join(converted_dir, filename)
            with open(filepath, "r", encoding="utf-8") as f:
                content = f.read()

            file_results = {}
            for check_name, pattern in checks.items():
                matches = list(pattern.finditer(content))
                if "no_" in check_name:
                    # 含まれていない = OK
                    file_results[check_name] = len(matches) == 0
                else:
                    # 含まれている = OK
                    file_results[check_name] = len(matches) > 0

            results[filename] = file_results

    # ======= 結果表示 =======
    print("=== 整合性チェック結果 ===")
    for file, checks in results.items():
        print(f"\n{file}")
        for check, passed in checks.items():
            print(f"  {check}: {'✅' if passed else '❌'}")
