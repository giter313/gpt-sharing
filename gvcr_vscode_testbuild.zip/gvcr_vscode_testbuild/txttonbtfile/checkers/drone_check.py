import os
import re

# ✅ フォルダのパスをここで指定
check_folder = "output_src/render/drone"

def check_java_file(filepath):
    issues = []
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()

        if "RenderLiving" in content:
            issues.append("❌ RenderLiving が残っています（MobRenderer に変換すべき）")
        if re.search(r'\bdoRender\s*\(', content):
            issues.append("❌ doRender メソッドが残っています（render に変換すべき）")
        if "GL11" in content or "GL12" in content:
            issues.append("⚠️ GL11 / GL12 の命令が残っています（PoseStack に変える必要あり）")

    return issues

def check_folder_java_files(folder):
    print(f"\n🔎 チェック開始: {folder}\n")
    any_issues = False
    for filename in sorted(os.listdir(folder)):
        if filename.endswith(".java"):
            filepath = os.path.join(folder, filename)
            issues = check_java_file(filepath)
            if issues:
                any_issues = True
                print(f"[!] {filename}:")
                for issue in issues:
                    print(f"   - {issue}")
                print()
    if not any_issues:
        print("✅ 問題は見つかりませんでした（すべて1.20.1準拠の形式です）")

if __name__ == "__main__":
    check_folder_java_files(check_folder)
