import os
import re
import sys

def check_java_file_for_1201(java_code: str, filename: str) -> bool:
    """
    1.20.1 に合わない可能性がある箇所を簡易チェック。
    合わなさそうな箇所を見つけたらFalseを返す。
    """

    problems = []

    # 1. 古い getDefaultState() が残っていないか
    if re.search(r'\.getDefaultState\(\)', java_code):
        problems.append("旧 getDefaultState() が残っています。→ .defaultBlockState() に変更してください。")

    # 2. setUnlocalizedName() が残っていないか
    if re.search(r'\.setUnlocalizedName\(', java_code):
        problems.append("setUnlocalizedName() が残っています。1.13以降は不要です。")

    # 3. CreativeTabs（旧）を使用していないか
    if re.search(r'\.setCreativeTab\(', java_code):
        problems.append("旧 CreativeTabs を使っています。CreativeModeTabs に置き換えが必要です。")

    # 4. @SideOnly アノテーションが残っていないか
    if re.search(r'@SideOnly', java_code):
        problems.append("@SideOnly アノテーションは削除してください。")

    # 5. BlockRenderLayer → RenderType への変換がされていないか
    if re.search(r'BlockRenderLayer', java_code):
        problems.append("BlockRenderLayer が残っています。RenderType に変更してください。")

    # 6. ItemBlock 関連の古いコードが残っていないか
    if re.search(r'ItemBlock', java_code):
        problems.append("ItemBlock 関連の古いコードがあります。")

    # 7. Texture名が文字列のままか（ResourceLocation への置換確認）
    if re.search(r'"[^"]*:[^"]*"', java_code) and not re.search(r'new ResourceLocation\(', java_code):
        problems.append("テクスチャ名が文字列のままです。new ResourceLocation に変更してください。")

    if problems:
        print(f"\n⚠️ ファイル: {filename} に問題があります：")
        for p in problems:
            print("  - " + p)
        return False

    # 問題なし
    return True


def check_all_files_in_folder(folder_path: str):
    all_ok = True
    for root, _, files in os.walk(folder_path):
        for file in files:
            if file.endswith(".java"):
                filepath = os.path.join(root, file)
                with open(filepath, 'r', encoding='utf-8') as f:
                    code = f.read()
                if not check_java_file_for_1201(code, filepath):
                    all_ok = False
    if all_ok:
        print(f"\n✅ フォルダ '{folder_path}' 内のすべてのJavaファイルは 1.20.1 に概ね対応しています。")
    else:
        print(f"\n❗️ フォルダ '{folder_path}' 内に 1.20.1 に対応していないファイルがあります。上記を確認してください。")


def main():
    if len(sys.argv) < 2:
        print("使い方: python check_forge1201.py <フォルダパス>")
        return
    folder = sys.argv[1]
    if not os.path.exists(folder):
        print(f"フォルダ '{folder}' が見つかりません。")
        return
    check_all_files_in_folder(folder)


if __name__ == "__main__":
    main()
