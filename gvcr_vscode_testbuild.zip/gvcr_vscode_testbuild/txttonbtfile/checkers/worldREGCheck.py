import os

# ======== 設定セクション ========
# チェック対象のディレクトリ（出力された1.20.1用コードのルート）
CHECK_DIR = "output/world"  # 例: "output/world"
# =================================

def check_deferred_register_usage(directory):
    found_files = []

    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith(".java"):
                file_path = os.path.join(root, file)
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        content = f.read()
                        if "DeferredRegister" in content:
                            found_files.append(file_path)
                except Exception as e:
                    print(f"[エラー] {file_path} を読み込めません: {e}")

    return found_files

if __name__ == "__main__":
    print(f"🔍 『{CHECK_DIR}』内で 'DeferredRegister' の使用をチェック中...\n")

    deferred_files = check_deferred_register_usage(CHECK_DIR)

    if deferred_files:
        print(f"⚠️ 以下のファイルで 'DeferredRegister' が使われています:\n")
        for file in deferred_files:
            print(f"  - {file}")
    else:
        print("✅ 'DeferredRegister' は検出されませんでした。使用されていません。")
