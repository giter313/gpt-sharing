import os
import re

def convert_gui_java_112_to_120(input_root, output_root):
    input_dir = os.path.join(input_root, "gui")
    output_dir = os.path.join(output_root, "gui")
    os.makedirs(output_dir, exist_ok=True)

    # containerフォルダは除外
    exclude_dirs = {"container"}

    for entry in os.listdir(input_dir):
        path = os.path.join(input_dir, entry)
        if os.path.isdir(path):
            if entry in exclude_dirs:
                continue
        if os.path.isfile(path) and entry.endswith(".java"):
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()

            # 継承クラス GuiContainer → ContainerScreen に置換
            content = re.sub(r'extends\s+GuiContainer', 'extends ContainerScreen<Container>', content)

            # importも必要なら置換
            content = content.replace("import net.minecraft.client.gui.inventory.GuiContainer;", 
                                      "import net.minecraft.client.gui.screens.inventory.ContainerScreen;")
            content = content.replace("import net.minecraft.inventory.Container;", 
                                      "import net.minecraft.world.inventory.Container;")

            # ボタン追加: addButton(new GuiButton(...)) → addButton(new Button(..., onPress -> { ... }))
            # ここは完全自動化は難しいので単純置換例（要手動修正）
            content = re.sub(r'addButton\(\s*new GuiButton\(([^)]*)\)\s*\)', r'addButton(new Button(\1, button -> { /* TODO: ボタン処理をここに記述 */ }))', content)

            # actionPerformed(GuiButton button) メソッドは削除 or コメントアウト
            content = re.sub(r'@Override\s*protected void actionPerformed\(GuiButton [^)]+\)\s*\{[^}]*\}', '// actionPerformed は 1.20.1では使いません', content, flags=re.DOTALL)

            # 描画メソッド drawTexturedModalRect → blit に置換（パラメータは要手動調整）
            content = re.sub(r'drawTexturedModalRect', 'blit', content)

            # アイテム描画 renderItemIntoGUI → renderGuiItem に置換
            content = content.replace('renderItemIntoGUI', 'renderGuiItem')

            # mc.getRenderItem() → mc.getItemRenderer()
            content = content.replace('mc.getRenderItem()', 'mc.getItemRenderer()')

            # OpenGL直接呼び出しは警告コメントを挿入（例）
            if 'GL11.' in content or 'GlStateManager.' in content:
                content = '// TODO: OpenGL呼び出しは1.20.1での推奨APIに置換してください\n' + content

            # 出力ファイルに書き込み
            output_path = os.path.join(output_dir, entry)
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(content)

            print(f"変換完了: {entry}")

if __name__ == "__main__":
    input_root = "input_src"
    output_root = "output_src"
    convert_gui_java_112_to_120(input_root, output_root)
