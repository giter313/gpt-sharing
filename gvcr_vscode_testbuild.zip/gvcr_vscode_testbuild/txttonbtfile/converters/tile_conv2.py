import os
import re

input_dir = "input_src/render/tile"
output_dir = "output_src/render/tile"
os.makedirs(output_dir, exist_ok=True)

for filename in os.listdir(input_dir):
    if not filename.endswith(".java"):
        continue

    with open(os.path.join(input_dir, filename), encoding='utf-8') as f:
        code = f.read()

    # 1. @SideOnly(Side.CLIENT) を削除
    code = re.sub(r'@SideOnly\s*\(\s*Side\.CLIENT\s*\)\s*\n?', '', code)

    # 2. 継承を implements BlockEntityRenderer<T> に変更
    code = re.sub(
        r'extends\s+TileEntitySpecialRenderer\s*<\s*(\w+)\s*>',
        r'implements BlockEntityRenderer<\1>',
        code
    )

    # 3. import 替え
    code = code.replace(
        'import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;',
        'import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;'
    )

    # 4. Minecraft.getMinecraft() → Minecraft.getInstance()
    code = code.replace('Minecraft.getMinecraft()', 'Minecraft.getInstance()')

    # 5. render メソッドの引数変換
    render_pattern = re.compile(
        r'public\s+void\s+render\s*\(\s*(\w+)\s+te\s*,\s*double\s+\w+\s*,\s*double\s+\w+\s*,\s*double\s+\w+\s*,\s*float\s+\w+\s*,\s*int\s+\w+\s*,\s*float\s+\w+\s*\)',
        re.MULTILINE
    )
    code = render_pattern.sub(
        r'@Override\n    public void render(\1 te, float partialTick, PoseStack poseStack, MultiBufferSource buffer, int packedLight, int packedOverlay)',
        code
    )

    # 6. 必要な import を追加（既存確認あり）
    if 'PoseStack' in code and 'com.mojang.blaze3d.vertex.PoseStack' not in code:
        code = re.sub(r'(package\s+[^\n]+;\n)', r'\1import com.mojang.blaze3d.vertex.PoseStack;\n', code)
    if 'MultiBufferSource' in code and 'net.minecraft.client.renderer.MultiBufferSource' not in code:
        code = re.sub(r'(package\s+[^\n]+;\n)', r'\1import net.minecraft.client.renderer.MultiBufferSource;\n', code)

    # 出力
    with open(os.path.join(output_dir, filename), "w", encoding='utf-8') as f:
        f.write(code)

print("✅ OpenGLを維持したTileEntityRenderer変換が完了しました（1.20.1対応）")
