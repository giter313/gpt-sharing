import os
import re

def convert_tileentity_to_blockentity(java_code):
    # 1. クラス宣言の置換
    java_code = re.sub(r"extends\s+TileEntityLockable", "extends BlockEntity", java_code)

    # 2. 不要なimport削除・必要なimport追加
    java_code = re.sub(r"import net\.minecraft\.tileentity\.TileEntityLockable;\n", "", java_code)
    java_code = re.sub(r"import net\.minecraft\.util\.ITickable;\n", "", java_code)
    java_code = re.sub(r"import net\.minecraft\.inventory\.ISidedInventory;\n", "", java_code)
    java_code = re.sub(r"import net\.minecraft\.util\.datafix\..*?;\n", "", java_code)

    imports_to_add = (
        "import net.minecraft.core.BlockPos;\n"
        "import net.minecraft.nbt.CompoundTag;\n"
        "import net.minecraft.world.level.block.entity.BlockEntity;\n"
        "import net.minecraft.world.level.block.state.BlockState;\n"
        "import net.minecraftforge.items.ItemStackHandler;\n"
        "import net.minecraftforge.common.util.LazyOptional;\n"
        "import net.minecraftforge.items.IItemHandler;\n"
        "import net.minecraftforge.items.CapabilityItemHandler;\n"
        "import net.minecraftforge.common.capabilities.Capability;\n"
        "import net.minecraftforge.common.capabilities.ICapabilityProvider;\n"
        "import net.minecraft.world.item.ItemStack;\n"
        "import net.minecraft.world.entity.player.Player;\n"
        "import net.minecraft.world.inventory.ContainerData;\n"
    )
    java_code = imports_to_add + java_code

    # 3. NonNullList<ItemStack> を ItemStackHandler に置換
    java_code = re.sub(r"NonNullList<.*?>\s+(\w+)\s*=.*?;",
                       r"ItemStackHandler \1 = new ItemStackHandler(8);", java_code)

    # 4. readFromNBT / writeToNBT → load / saveAdditional
    java_code = re.sub(r"public void readFromNBT\(NBTTagCompound compound\)",
                       "@Override\n    public void load(CompoundTag compound)", java_code)
    java_code = re.sub(r"public NBTTagCompound writeToNBT\(NBTTagCompound compound\)",
                       "@Override\n    public void saveAdditional(CompoundTag compound)", java_code)

    # 5. world.getTileEntity → level.getBlockEntity
    java_code = re.sub(r"\bthis\.world\.getTileEntity", "this.level.getBlockEntity", java_code)

    # 6. EntityPlayer → Player
    java_code = java_code.replace("EntityPlayer", "Player")

    # 7. InventoryPlayer → 無効化（使われていない場合は削除）
    java_code = re.sub(r"import net\.minecraft\.entity\.player\.InventoryPlayer;\n", "", java_code)
    java_code = re.sub(r"InventoryPlayer\s+\w+,?\s*", "", java_code)

    # 8. TileEntityのregisterFixesなどを削除
    java_code = re.sub(r"(?s)public static void registerFixesFurnace.*?}\n", "", java_code)

    # 9. openInventory / closeInventory を削除または空関数へ
    java_code = re.sub(r"public void openInventory\(.*?\)\s*{.*?}\n", "@Override\n    public void onLoad() {}\n", java_code, flags=re.DOTALL)
    java_code = re.sub(r"public void closeInventory\(.*?\)\s*{.*?}\n", "", java_code, flags=re.DOTALL)

    return java_code


def convert_all_in_folder(input_folder, output_folder):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    for filename in os.listdir(input_folder):
        if filename.endswith(".java"):
            input_path = os.path.join(input_folder, filename)
            output_path = os.path.join(output_folder, filename)

            with open(input_path, "r", encoding="utf-8") as infile:
                original_code = infile.read()

            converted_code = convert_tileentity_to_blockentity(original_code)

            with open(output_path, "w", encoding="utf-8") as outfile:
                outfile.write(converted_code)

            print(f"変換完了: {filename}")


# 使用例
if __name__ == "__main__":
    input_dir = "input_src/block/tile"   # 1.12.2のTileEntity Javaファイルが入っているフォルダ
    output_dir = "output_src/block/tile"  # 変換後の出力フォルダ
    convert_all_in_folder(input_dir, output_dir)
