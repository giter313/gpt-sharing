import os
import re

input_folder = "input_src/render/boss"
output_folder = "output_src/render/boss"

os.makedirs(output_folder, exist_ok=True)

def convert_render_boss_112_to_120(content):
    # SideOnly 削除
    content = re.sub(r'@SideOnly\(Side\.CLIENT\)\s*\n', '', content)

    # import の SideOnly 関連削除
    content = re.sub(r'import\s+net\.minecraftforge\.fml\.relauncher\.SideOnly;\s*\n', '', content)
    content = re.sub(r'import\s+net\.minecraftforge\.fml\.relauncher\.Side;\s*\n', '', content)

    # super.doRender → super.render に変更（メソッド名変更に対応）
    content = re.sub(r'\bsuper\.doRender\b', 'super.render', content)

    # コメント付きで未使用メソッドのJavadoc除去（変換簡略化）
    content = re.sub(r'/\*\*.*?\*/\s*', '', content, flags=re.DOTALL)

    return content

for filename in os.listdir(input_folder):
    if filename.endswith(".java"):
        with open(os.path.join(input_folder, filename), "r", encoding="utf-8") as f:
            original_code = f.read()

        converted_code = convert_render_boss_112_to_120(original_code)

        with open(os.path.join(output_folder, filename), "w", encoding="utf-8") as f:
            f.write(converted_code)

print("✅ /boss フォルダ内のレンダラー変換が完了しました。")
