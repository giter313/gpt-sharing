import os
import re
import shutil

# 変換ルール（前回のまま）
FOLDER_RULES = {
    "ai": {
        r"\bEntityAIBase\b": "Goal",
        r"\bshouldExecute\s*\(\s*\)": "canUse()",
        r"\bcontinueExecuting\s*\(\s*\)": "canContinueToUse()",
        r"\bstartExecuting\s*\(\s*\)": "start()",
        r"\bresetTask\s*\(\s*\)": "stop()",
        r"\bupdateTask\s*\(\s*\)": "tick()",
        r"\bthis\.tasks\.addTask\b": "this.goalSelector.addGoal",
    },
    "boss": {
        r"\bEntityMob\b": "Monster",
        r"\bBossInfoServer\b": "ServerBossEvent",
        r"\bonUpdate\s*\(\s*\)": "tick()",
        r"\bworld\.spawnEntity\b": "level.addFreshEntity",
        r"\bisNonBoss\s*\(\s*\)": "// removed isNonBoss(), manage with BossBar",
    },
    "bullet": {
        r"\bEntityThrowable\b": "Projectile",
        r"\bonImpact\s*\(": "onHit(",
        r"\bsetDead\s*\(\s*\)": "discard()",
        r"\bmotion([XYZ])\b": r"getDeltaMovement().\1.lower()",
        r"\bworld\.spawnEntity\b": "level.addFreshEntity",
    },
    "drone": {
        r"\bEntityMob\b": "FlyingMob",
        r"\bonUpdate\s*\(\s*\)": "tick()",
        r"\bmove\s*\(([^,]+),\s*(.+)\)": r"setDeltaMovement(\2); moveRelative(0.1F, \2);",
        r"\bdataManager\b": "entityData",
        r"fallDistance\s*=\s*0\.0f": "setNoGravity(true)",
    },
    "mob": {
        r"\bEntityMob\b": "Monster",
        r"\bonUpdate\s*\(\s*\)": "tick()",
        r"\battackEntityAsMob\b": "doHurtTarget",
        r"\bdataManager\b": "entityData",
    },
    "npc": {
        r"\binteract\s*\(([^,]+),\s*([^)]+)\)": r"mobInteract(\1, \2)",
        r"\bworld\.spawnEntity\b": "level.addFreshEntity",
        r"\bdataManager\b": "entityData",
    },
    "pmc": {
        r"\bEntityMob\b": "Monster",
        r"\bdataManager\b": "entityData",
        r"\bonUpdate\s*\(\s*\)": "tick()",
    },
    "so": {
        r"\bEntityMob\b": "Monster",
        r"\bdataManager\b": "entityData",
        r"\bonUpdate\s*\(\s*\)": "tick()",
    },
    "vehicle": {
        r"\bEntity\b": "AbstractVehicle",
        r"\bmove\s*\(([^,]+),\s*(.+)\)": r"setDeltaMovement(\2); moveRelative(0.1F, \2);",
        r"\bgetControllingPassenger\s*\(\s*\)": "getFirstPassenger()",
        r"\bsetDead\s*\(\s*\)": "discard()",
        r"\bworld\.spawnEntity\b": "level.addFreshEntity",
        r"\bgetPassengers\s*\(\)\.get\s*\((\d+)\)": r"getPassengers().get(\1)",
    }
}

COMMON_RULES = {
    r"\bthis\.world\b": "this.level",
    r"\bisDead\s*\(\s*\)": "isRemoved()",
    r"\bonCollideWithPlayer\b": "playerTouch",
    r"\bwriteToNBT\b": "addAdditionalSaveData",
    r"\breadFromNBT\b": "readAdditionalSaveData",
    r"\bdataManager\b": "entityData",
    r"RenderingRegistry\.registerEntityRenderingHandler": "EntityRenderers.register",
}

def apply_rules(text: str, rules: dict) -> str:
    for pattern, repl in rules.items():
        text = re.sub(pattern, repl, text)
    return text

def detect_folder_type(path: str) -> str:
    path = path.replace("\\", "/")
    for folder in FOLDER_RULES.keys():
        if f"/{folder}/" in path:
            return folder
    return ""

def convert_entity_files(src_dir: str, dst_dir: str):
    if not os.path.exists(dst_dir):
        os.makedirs(dst_dir)

    for root, _, files in os.walk(src_dir):
        for name in files:
            if name.endswith(".java"):
                src_path = os.path.join(root, name)
                rel_path = os.path.relpath(src_path, src_dir)  # 入力フォルダからの相対パス
                dst_path = os.path.join(dst_dir, rel_path)

                # 出力先のフォルダも作る
                os.makedirs(os.path.dirname(dst_path), exist_ok=True)

                folder = detect_folder_type(src_path)
                with open(src_path, "r", encoding="utf-8") as f:
                    content = f.read()

                # 変換適用
                if folder in FOLDER_RULES:
                    content = apply_rules(content, FOLDER_RULES[folder])
                content = apply_rules(content, COMMON_RULES)

                # 出力
                with open(dst_path, "w", encoding="utf-8") as f:
                    f.write(content)

                print(f"[✓] Converted: {rel_path}")

if __name__ == "__main__":
    # 入力フォルダ（1.12.2ソース）
    input_folder = "input_src/entity"
    # 出力フォルダ（変換済み1.20.1ソース）
    output_folder = "output_src/entity"

    convert_entity_files(input_folder, output_folder)
