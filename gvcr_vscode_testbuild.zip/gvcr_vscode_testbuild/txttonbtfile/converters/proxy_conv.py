import os
import re

BLOCK_DIR = "output_src/block"
PROXY_FILE = "CommonProxyGVCR2.java"

def find_classes(prefix, content):
    """指定された接頭辞をもつクラス名をすべて抽出"""
    pattern = rf'public\s+class\s+({prefix}[A-Za-z0-9_]+)'
    return re.findall(pattern, content)

def get_existing_registrations(proxy_content, type_):
    if type_ == "tile":
        return set(re.findall(r'GameRegistry\.registerTileEntity\(\s*(TileEntity_[A-Za-z0-9_]+)\.class\s*,\s*"[^"]+"\s*\)', proxy_content))
    elif type_ == "block":
        return set(re.findall(r'GameRegistry\.registerBlock\(\s*new\s+(Block_[A-Za-z0-9_]+)\(\)', proxy_content))
    return set()

def insert_into_register_method(proxy_content, new_lines):
    """registerTileEntities() メソッド内に new_lines を追加する"""
    pattern = r'(public\s+void\s+registerTileEntities\s*\(\s*\)\s*\{\s*)(.*?)(\s*\})'
    match = re.search(pattern, proxy_content, re.DOTALL)
    if match:
        head, body, tail = match.groups()
        updated_body = body.rstrip() + "\n" + "\n".join(new_lines) + "\n"
        return proxy_content[:match.start()] + head + updated_body + tail + proxy_content[match.end():]
    else:
        # メソッドが存在しない場合、新規で追加
        method_code = "\n    public void registerTileEntities() {\n" + "\n".join(new_lines) + "\n    }\n"
        return re.sub(r'\n\}', method_code + "\n}", proxy_content)

def main():
    tile_entities = set()
    block_classes = set()

    for root, _, files in os.walk(BLOCK_DIR):
        for file in files:
            if file.endswith(".java"):
                file_path = os.path.join(root, file)
                with open(file_path, "r", encoding="utf-8") as f:
                    content = f.read()
                    tile_entities.update(find_classes("TileEntity_", content))
                    block_classes.update(find_classes("Block_", content))

    with open(PROXY_FILE, "r", encoding="utf-8") as f:
        proxy_content = f.read()

    registered_tiles = get_existing_registrations(proxy_content, "tile")
    registered_blocks = get_existing_registrations(proxy_content, "block")

    new_lines = []

    for te in sorted(tile_entities - registered_tiles):
        new_lines.append(f'        GameRegistry.registerTileEntity({te}.class, "{te.lower()}");')

    for blk in sorted(block_classes - registered_blocks):
        new_lines.append(f'        GameRegistry.registerBlock(new {blk}(), "{blk.lower()}");')

    if not new_lines:
        print("新しく追加する登録はありません。")
        return

    updated_content = insert_into_register_method(proxy_content, new_lines)

    with open(PROXY_FILE, "w", encoding="utf-8") as f:
        f.write(updated_content)

    print(f"{len(new_lines)} 件の登録を CommonProxyGVCR2.java に追加しました。")

if __name__ == "__main__":
    main()
