import os
import re

def convert_java_block_file_112_to_120(java_code: str) -> str:
    # 1. クラス宣言（Block → Block）
    java_code = re.sub(r'extends Block( ?implements .*?)? {', r'extends Block {', java_code)

    # 2. IHasModel 実装の削除
    java_code = re.sub(r'(implements\s+IHasModel\s*)', '', java_code)
    java_code = re.sub(r'@Override\s+public void registerModels\(.*?\}\s+', '', java_code, flags=re.DOTALL)

    # 3. getDefaultState() → defaultBlockState()
    java_code = re.sub(r'\.getDefaultState\(\)', '.defaultBlockState()', java_code)

    # 4. setUnlocalizedName → Forge 1.13+ 非推奨 → 削除
    java_code = re.sub(r'\.setUnlocalizedName\([^)]+\)', '', java_code)

    # 5. setRegistryName → 形式保持（必要に応じて変換）
    java_code = re.sub(r'\.setRegistryName\(([^\)]+)\)', r'.setRegistryName(\1)', java_code)

    # 6. CreativeTabs → 削除または変換
    java_code = re.sub(r'\.setCreativeTab\([^)]+\)', '', java_code)

    # 7. BlockMaterial, SoundType → フィールド名はそのまま保持
    java_code = re.sub(r'Material\.([A-Z_]+)', r'Material.\1', java_code)
    java_code = re.sub(r'SoundType\.([A-Z_]+)', r'SoundType.\1', java_code)

    # 8. @SideOnly → 削除
    java_code = re.sub(r'@SideOnly\(Side\.CLIENT\)\s*', '', java_code)

    # 9. BlockRenderLayer → RenderType に置換
    java_code = re.sub(r'BlockRenderLayer', 'RenderType', java_code)
    java_code = re.sub(r'getRenderLayer\(\)', 'getRenderType()', java_code)

    # 10. ItemBlock 登録行の削除
    java_code = re.sub(r'.*ItemBlock.*\n', '', java_code)

    # 11. テクスチャ名を ResourceLocation に変換
    java_code = re.sub(r'"gvcr2:([^"]+)"', r'new ResourceLocation("gvcr2", "\1")', java_code)

    return java_code

def convert_all_block_java_files(input_folder: str = "input_src/block", output_folder: str = "output_src/block"):
    os.makedirs(output_folder, exist_ok=True)
    for filename in os.listdir(input_folder):
        if filename.endswith(".java"):
            input_path = os.path.join(input_folder, filename)
            output_path = os.path.join(output_folder, filename)
            with open(input_path, 'r', encoding='utf-8') as f:
                original_code = f.read()
            converted_code = convert_java_block_file_112_to_120(original_code)
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(converted_code)
    print(f"✅ 変換完了: {input_folder} → {output_folder}")

# 実行
if __name__ == "__main__":
    convert_all_block_java_files()
