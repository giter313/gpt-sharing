import os
import re
import sys

def convert_tile_renderer_java(java_code: str) -> str:
    class_match = re.search(r'public class (\w+)\s+extends TileEntitySpecialRenderer<([\w_]+)>', java_code)
    if not class_match:
        return "// クラス定義が見つかりません"

    class_name = class_match.group(1)
    tile_entity_class = class_match.group(2)

    texture_defs = re.findall(r'ResourceLocation\s+(\w+)\s*=\s*new ResourceLocation\("([^"]+)"\);', java_code)
    model_defs = re.findall(r'IModelCustom\s+(\w+)\s*=\s*AdvancedModelLoader\.loadModel\(new ResourceLocation\("([^"]+)"\)\);', java_code)
    facing_rotations = re.findall(r'if\s*\(\s*te\.facing\s*==\s*(\d)\)\s*\{\s*GL11\.glRotatef\(([-\d.]+)', java_code)

    render_blocks = re.findall(
        r'if\s*\(te\.(\w+)\s*==\s*(\d+)\)\s*\{\s*this\.bindTexture\((\w+)\);\s*(\w+)\.renderPart\("([^"]+)"\");',
        java_code.replace("\n", " ").replace("\r", "")
    )

    lines = []
    lines.append("package gvcr2.render.tile;")
    lines.append("")
    lines.append("import com.mojang.blaze3d.vertex.PoseStack;")
    lines.append("import net.minecraft.client.renderer.MultiBufferSource;")
    lines.append("import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;")
    lines.append("import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;")
    lines.append("import net.minecraft.resources.ResourceLocation;")
    lines.append(f"import gvcr2.block.tile.{tile_entity_class};")
    lines.append("import objmodel.AdvancedModelLoader;")
    lines.append("import objmodel.IModelCustom;")
    lines.append("")
    lines.append(f"public class {class_name} implements BlockEntityRenderer<{tile_entity_class}> {{")
    lines.append("")

    for tex_var, tex_path in texture_defs:
        lines.append(f"    private static final ResourceLocation {tex_var} = new ResourceLocation(\"{tex_path}\");")
    for model_var, model_path in model_defs:
        lines.append(f"    private static final IModelCustom {model_var} = AdvancedModelLoader.loadModel(new ResourceLocation(\"{model_path}\"));")

    lines.append("")
    lines.append(f"    public {class_name}(BlockEntityRendererProvider.Context context) {{}}")
    lines.append("")
    lines.append("    @Override")
    lines.append(f"    public void render({tile_entity_class} te, float partialTicks, PoseStack poseStack,")
    lines.append("                        MultiBufferSource buffer, int packedLight, int packedOverlay) {")
    lines.append("        // WARNING: GL11 calls are deprecated in 1.20.1. Consider using PoseStack-based transforms.")
    lines.append("        poseStack.pushPose();")
    lines.append("        poseStack.translate(0.5, 0, 0.5);")
    lines.append("        poseStack.mulPose(com.mojang.math.Axis.YP.rotationDegrees(180.0F));")

    for facing, rot in facing_rotations:
        lines.append(f"        if (te.facing == {facing}) poseStack.mulPose(com.mojang.math.Axis.YP.rotationDegrees({rot}F));")

    lines.append("")
    for field, val, tex, model, part in render_blocks:
        lines.append(f"        if (te.{field} == {val}) {{")
        lines.append(f"            AdvancedModelLoader.renderPart(poseStack, {model}, \"{part}\", {tex}, buffer, packedLight);")
        lines.append("        }")

    lines.append("        poseStack.popPose();")
    lines.append("    }")
    lines.append("}")
    return "\n".join(lines)

def convert_all_tile_renderers(input_folder: str):
    if not os.path.isdir(input_folder):
        print(f"[エラー] 指定されたフォルダが存在しません: {input_folder}")
        return

    print(f"[開始] フォルダ内の TileRender_*.java を変換中: {input_folder}")

    for filename in os.listdir(input_folder):
        if filename.endswith(".java") and filename.startswith("TileRender_"):
            input_path = os.path.join(input_folder, filename)
            with open(input_path, "r", encoding="utf-8") as f:
                java_code = f.read()

            converted = convert_tile_renderer_java(java_code)

            output_filename = filename.replace(".java", "_Converted.java")
            output_path = os.path.join(input_folder, output_filename)

            with open(output_path, "w", encoding="utf-8") as f:
                f.write(converted)

            print(f"[✔] {filename} -> {output_filename}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("使い方: python batch_convert_tile_renderers.py <tileフォルダのパス>")
        sys.exit(1)

    folder_path = sys.argv[1]
    convert_all_tile_renderers(folder_path)
