import os
import json

OUTPUT_FOLDER = "output"

def validate_nbt_file(filepath):
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)

        errors = []

        # blocks検証
        blocks = data.get("blocks")
        if not isinstance(blocks, list):
        else:
            for i, block in enumerate(blocks):
                for key in ["Name", "x", "y", "z", "Properties"]:
                    if key not in block:
                        errors.append(f"blocks[{i}] に '{key}' がありません")

        # tile_entities検証（任意）
        tile_entities = data.get("tile_entities", [])
        if not isinstance(tile_entities, list):
            errors.append("tile_entities フィールドが list ではありません")
        else:
            for i, tile in enumerate(tile_entities):
                for key in ["id", "x", "y", "z", "Items"]:
                    if key not in tile:
                        errors.append(f"tile_entities[{i}] に '{key}' がありません")

        if errors:
            print(f"❌ 不正: {filepath}")
            for err in errors:
                print(f"   - {err}")
        else:
            print(f"✅ OK: {filepath}")

    except Exception as e:
        print(f"❌ 読込エラー: {filepath} → {e}")

def main():
    for file in os.listdir(OUTPUT_FOLDER):
        if file.endswith(".nbt"):
            filepath = os.path.join(OUTPUT_FOLDER, file)
            validate_nbt_file(filepath)

if __name__ == "__main__":
    main()
