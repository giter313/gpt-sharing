import os
import json

INPUT_DIR = "iteminput"
OUTPUT_DIR = "itemoutput"

def convert_block_textures(textures):
    new_textures = {}
    for key, value in textures.items():
        # 例: gvcr2:blocks/nulls → gvcr2:block/nulls
        new_textures[key] = value.replace("blocks/", "block/")
    return new_textures

def convert_item_textures(textures):
    new_textures = {}
    for key, value in textures.items():
        # 例: gvcr2:items/item/xxx → gvcr2:item/xxx
        new_textures[key] = value.replace("items/item/", "item/")
    return new_textures

def convert_block_model(filepath, outpath):
    with open(filepath, 'r', encoding='utf-8') as f:
        data = json.load(f)
    textures = convert_block_textures(data.get("textures", {}))

    result = {
        "parent": "block/cube",
        "textures": textures
    }

    os.makedirs(os.path.dirname(outpath), exist_ok=True)
    with open(outpath, 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2)
    print(f"✅ ブロック変換: {filepath} → {outpath}")

def convert_item_model(filepath, outpath):
    with open(filepath, 'r', encoding='utf-8') as f:
        data = json.load(f)

    # texturesのパスだけ変換
    data["textures"] = convert_item_textures(data.get("textures", {}))

    os.makedirs(os.path.dirname(outpath), exist_ok=True)
    with open(outpath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2)
    print(f"✅ アイテム変換: {filepath} → {outpath}")

def main():
    for root, _, files in os.walk(os.path.join(INPUT_DIR, "models", "block")):
        for filename in files:
            if filename.endswith(".json"):
                in_path = os.path.join(root, filename)
                out_path = in_path.replace(INPUT_DIR, OUTPUT_DIR)
                convert_block_model(in_path, out_path)

    for root, _, files in os.walk(os.path.join(INPUT_DIR, "models", "item")):
        for filename in files:
            if filename.endswith(".json"):
                in_path = os.path.join(root, filename)
                out_path = in_path.replace(INPUT_DIR, OUTPUT_DIR)
                convert_item_model(in_path, out_path)

if __name__ == "__main__":
    main()
