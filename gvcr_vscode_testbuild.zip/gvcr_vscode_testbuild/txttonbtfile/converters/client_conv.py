import os
import re

# ------------------------
# 変換ルール定義（client用）
# ------------------------
CLIENT_REPLACEMENTS = [
    (r'\bMinecraft\.getMinecraft\s*\(\)', 'Minecraft.getInstance()'),
    (r'\bmc\.getRenderManager\s*\(\)', 'Minecraft.getInstance().getEntityRenderDispatcher()'),
    (r'\bVec3d\b', 'Vec3'),
    (r'new Vec3\s*\(([^)]+)\)', r'new Vec3(\1)'),
    (r'new Vec3d\s*\(([^)]+)\)', r'new Vec3(\1)'),
    (r'net\.minecraft\.util\.math\.Vec3d', 'net.minecraft.world.phys.Vec3'),

    # TessellatorとBufferBuilderの置換メモコメント
    (r'Tessellator\.getInstance\s*\(\)', '// Tessellator → Minecraft.getInstance().renderBuffers().bufferSource() に置き換え推奨'),
    (r'BufferBuilder', '// BufferBuilder は VertexConsumer へ書き換えが必要'),

    # GL系命令の削除や置き換えコメント
    (r'GL11\.gl(PushMatrix|PopMatrix|Translated|Translatef|Color4f|Color4f|Disable|Enable|DepthMask|AlphaFunc|BlendFunc)\s*\([^\)]*\);?', r'// 削除 or PoseStack に置換'),
    (r'GlStateManager\.[a-zA-Z0-9_]+\s*\([^\)]*\);?', r'// GlStateManager → PoseStack へ書き換え'),

    # MinecraftForge.EVENT_BUS.register → 静的イベント登録推奨コメント
    (r'MinecraftForge\.EVENT_BUS\.register\s*\(\s*this\s*\);?', '// イベント登録は @Mod.EventBusSubscriber で静的登録推奨'),

    # RenderWorldLastEvent
    (r'\bRenderWorldLastEvent\b', 'RenderWorldLastEvent  // OpenGL → PoseStack に書き換え必要'),

    # Camera位置取得
    (r'\bgetRenderViewEntity\(\)\.getPositionEyes\s*\([^\)]*\)', 'gameRenderer.getMainCamera().getPosition()'),
]

# ------------------------
# 変換実行関数
# ------------------------
def convert_client_event_folder(input_dir, output_dir):
    input_path = os.path.join(input_dir, "event", "client")
    output_path = os.path.join(output_dir, "event", "client")
    os.makedirs(output_path, exist_ok=True)

    if not os.path.exists(input_path):
        print(f"[スキップ] 入力フォルダが存在しません: {input_path}")
        return

    for file in os.listdir(input_path):
        if not file.endswith(".java"):
            continue

        full_input = os.path.join(input_path, file)
        full_output = os.path.join(output_path, file)

        with open(full_input, "r", encoding="utf-8") as f:
            content = f.read()

        for pattern, repl in CLIENT_REPLACEMENTS:
            content = re.sub(pattern, repl, content)

        content = "// ⚠ 一部OpenGL命令はPoseStackでの置き換えが必要です。コード内のコメントを参照してください。\n" + content

        with open(full_output, "w", encoding="utf-8") as f:
            f.write(content)

        print(f"[変換完了] client/{file}")

# ------------------------
# 実行部分
# ------------------------
if __name__ == "__main__":
    input_root = "input_src"
    output_root = "output_src"

    convert_client_event_folder(input_root, output_root)
    print("\n✅ client フォルダの変換が完了しました。出力先: output/src/gvcr2/event/client/")
