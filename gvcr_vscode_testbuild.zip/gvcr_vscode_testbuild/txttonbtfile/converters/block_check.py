import os
import json

CHECK_FOLDERS = [
    "itemoutput/models/block",
    "itemoutput/models/item",
]

def check_texture_paths(json_data, filepath):
    problems = []
    textures = json_data.get("textures")
    if not textures:
        return problems
    for key, val in textures.items():
        if isinstance(val, str) and "gvcr2:blocks/" in val:
            problems.append((key, val))
    return problems

def main():
    problem_files = 0
    problem_entries = 0

    for base_folder in CHECK_FOLDERS:
        if not os.path.isdir(base_folder):
            print(f"⚠️ フォルダが見つかりません: {base_folder}")
            continue
        for root, _, files in os.walk(base_folder):
            for filename in files:
                if not filename.endswith(".json"):
                    continue
                filepath = os.path.join(root, filename)
                try:
                    with open(filepath, "r", encoding="utf-8") as f:
                        data = json.load(f)
                except Exception as e:
                    print(f"⚠️ JSON読み込み失敗: {filepath} ({e})")
                    continue

                problems = check_texture_paths(data, filepath)
                if problems:
                    problem_files += 1
                    print(f"🚨 問題あり: {filepath}")
                    for key, val in problems:
                        problem_entries += 1
                        print(f"   ⚠️ テクスチャパスがForge 1.20.1形式でない: '{key}': '{val}'")

    if problem_files == 0:
        print("✅ 全ファイル問題なし")
    else:
        print(f"⚠️ 問題ファイル数: {problem_files} 件, 問題箇所合計: {problem_entries} 件")

if __name__ == "__main__":
    main()
