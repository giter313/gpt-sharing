import os

def convert_gui_container_java(input_root, output_root):
    input_dir = os.path.join(input_root, "gui", "container")
    output_dir = os.path.join(output_root, "gui", "container")

    if not os.path.exists(input_dir):
        print(f"入力フォルダが存在しません: {input_dir}")
        return

    os.makedirs(output_dir, exist_ok=True)

    for filename in os.listdir(input_dir):
        if filename.endswith(".java"):
            input_path = os.path.join(input_dir, filename)
            output_path = os.path.join(output_dir, filename)

            with open(input_path, "r", encoding="utf-8") as f:
                content = f.read()

            # 変換例: package行の変更や他の処理があればここで
            # 今回は例としてpackage名を置換(必要に応じて編集してください)
            content = content.replace("package gvcr2.gui.container;", "package gvcr2.gui.container;")

            # 出力
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(content)

            print(f"変換済み: {filename}")

if __name__ == "__main__":
    input_root = "input_src"
    output_root = "output_src"
    convert_gui_container_java(input_root, output_root)
